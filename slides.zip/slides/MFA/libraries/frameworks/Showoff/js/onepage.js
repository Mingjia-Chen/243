function setupOnePage() {
  sh_highlightDocument();
  centerSlides($("#slides > .slide"))
}
